window.onload=function(){
    var input=document.getElementById("input")

    input.onfocus=function(){
        input.value="";
    }
}